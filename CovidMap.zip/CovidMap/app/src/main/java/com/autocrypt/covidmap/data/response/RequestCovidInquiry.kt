package com.autocrypt.covidmap.data.response

data class RequestCovidInquiry(
    val page: Int,
    val perPage: Int
)
